
export class Dolar {
    constructor(public fecha: Date, public precioventanacion: number) {}
  }
  