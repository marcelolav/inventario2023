export class Cliente {

  constructor(public nombre: string, public direccion: string) {
  }
}
