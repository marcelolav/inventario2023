import {Injectable} from '@angular/core';
import {HttpService} from "../servicios/http.service";
import {Producto} from "../modelos/producto";

@Injectable({
  providedIn: 'root'
})
export class VentasService {

  constructor(private http: HttpService) {
  }


  public async obtenerVentas() {
    return await this.http.get("/ventas");
  }

  public async obtenerDetalleDeVenta(idVenta) {
    return await this.http.get("/detalle_venta?id=".concat(idVenta));
  }

  public async obtenerVentasPorFecha(dia, mes, anio) {
     return await this.http.get("/ventasfecha?dia=". concat(dia) .concat("&mes=".concat(mes) .concat("&anio=") .concat(anio)))
  }
  
}
