import { Injectable } from '@angular/core';
import { Dolar } from './../modelos/dolar';
import { HttpService } from '../servicios/http.service';

@Injectable({
  providedIn: 'root'
})

export class DolarService {

  constructor(private http: HttpService) { }

  public async obtenerCotizaciones() {
    return await this.http.get("/dolartodos");
  }
  public async obtenerCotizacionPorFecha(dia, mes, anio) {
    return await this.http.get("/dolarfecha?dia=". concat(dia) .concat("&mes=".concat(mes) .concat("&anio=") .concat(anio)))
  }
 
 public async agregarCotizacion(cotizacion: Dolar) {
  return await this.http.post("/refdolar", cotizacion);
  }
}
