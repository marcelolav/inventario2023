// Modulos basicos de sistema
import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {MatSliderModule} from '@angular/material/slider';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule} from "@angular/forms";
import {MatSidenavModule} from '@angular/material/sidenav';

// Modulos de angular material
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatListModule} from '@angular/material/list';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTableModule} from '@angular/material/table';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatInputModule} from "@angular/material/input";
import {MatProgressSpinnerModule} from "@angular/material/progress-spinner";
import {MatCardMdImage, MatCardModule} from "@angular/material/card";
import {MatChipsModule} from "@angular/material/chips";
import {MatGridListModule} from "@angular/material/grid-list";
import {MatBadgeModule} from "@angular/material/badge";
import {MatMenuModule} from "@angular/material/menu";
import {MatStepperModule} from "@angular/material/stepper";

// Modulos creados por usuarios
import { ProductosComponent } from './componentes/productos/productos.component';
import { VentasComponent } from './componentes/ventas/ventas.component';
import { TiendaComponent } from './componentes/tienda/tienda.component';
import { AgregarProductoComponent } from './componentes/agregar-producto/agregar-producto.component';
import { LoadingButtonComponent } from './componentes/loading-button/loading-button.component';
import { TarjetaProductoComponent } from './componentes/tarjeta-producto/tarjeta-producto.component';
import { DetalleDeProductoComponent } from './componentes/detalle-de-producto/detalle-de-producto.component';
import { TerminarCompraComponent } from './componentes/terminar-compra/terminar-compra.component';
import { DetalleDeVentaComponent } from './componentes/detalle-de-venta/detalle-de-venta.component';
import { BuscarProductoComponent } from './componentes/buscar-producto/buscar-producto.component';
import { ConsultarVentasComponent } from './componentes/consultar-ventas/consultar-ventas.component';
import { ComprasComponent } from './componentes/compras/compras.component';
import { ControlPreciosComponent } from './componentes/control-precios/control-precios.component';
import { InventarioComponent } from './componentes/inventario/inventario.component';
import { DolarComponent } from './componentes/dolar/dolar.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductosComponent,
    VentasComponent,
    TiendaComponent,
    AgregarProductoComponent,
    LoadingButtonComponent,
    TarjetaProductoComponent,
    DetalleDeProductoComponent,
    TerminarCompraComponent,
    DetalleDeVentaComponent,
    BuscarProductoComponent,
    ConsultarVentasComponent,
    ComprasComponent,
    ControlPreciosComponent,
    InventarioComponent,
    DolarComponent    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSliderModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatIconModule,
    MatButtonModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatTableModule,
    MatDialogModule,
    MatSnackBarModule,
    MatInputModule,
    FormsModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatGridListModule,
    MatChipsModule,
    MatBadgeModule,
    MatMenuModule,
    MatStepperModule,
   // MatCardMdImage
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
