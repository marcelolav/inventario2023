import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ProductosComponent} from './componentes/productos/productos.component';
import {VentasComponent} from './componentes/ventas/ventas.component';
import {TiendaComponent} from './componentes/tienda/tienda.component';
import {AgregarProductoComponent} from "./componentes/agregar-producto/agregar-producto.component";
import {DetalleDeProductoComponent} from "./componentes/detalle-de-producto/detalle-de-producto.component";
import {TerminarCompraComponent} from "./componentes/terminar-compra/terminar-compra.component";
import {DetalleDeVentaComponent} from "./componentes/detalle-de-venta/detalle-de-venta.component";
import { BuscarProductoComponent } from './componentes/buscar-producto/buscar-producto.component';
import { ConsultarVentasComponent } from './componentes/consultar-ventas/consultar-ventas.component';
import { ComprasComponent } from './componentes/compras/compras.component';
import { ControlPreciosComponent } from './componentes/control-precios/control-precios.component';
import { InventarioComponent } from './componentes/inventario/inventario.component';
import { DolarComponent } from './componentes/dolar/dolar.component';


const routes: Routes = [
  {path: 'productos', component: ProductosComponent},
  {path: 'productos/agregar', component: AgregarProductoComponent},
  {path: 'ventas', component: VentasComponent},
  {path: 'tienda', component: TiendaComponent},
  {path: 'producto/detalle/:id', component: DetalleDeProductoComponent},
  {path: 'producto/buscar', component: BuscarProductoComponent },
  {path: 'terminar_compra', component: TerminarCompraComponent},
  {path: 'detalle-venta/:id', component: DetalleDeVentaComponent},
  {path: 'consulta-ventas', component: ConsultarVentasComponent },
  {path: 'compras', component: ComprasComponent },
  {path: 'control-precios', component: ControlPreciosComponent },
  {path: 'inventario', component: InventarioComponent },
  {path: 'dolar', component: DolarComponent },
  {path: '', redirectTo: "/tienda", pathMatch: "full"},
  {path: '**', redirectTo: "/tienda"},
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true, // <- Indicar que se use el hash
  })],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
