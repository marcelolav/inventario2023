import {Component, OnInit} from '@angular/core';
import {VentasService} from "../../servicios/ventas.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-ventas',
  templateUrl: './consultar-ventas.component.html',
  styleUrls: ['./consultar-ventas.component.css']
})
export class ConsultarVentasComponent implements OnInit {

  constructor(private ventasService: VentasService, private router:Router) {
  }

  public ventas = [];
  public fecha = new Date();
  public columnas = ['cliente', 'direccion', 'total', 'fecha', 'detalles'];

  // modificado para mostrar dia actual de ventas
  async ngOnInit() {
    this.ventas = await this.ventasService.obtenerVentas();
  }

  public verDetalle(id) {
    this.router.navigate(["/detalle-venta", id])
  }

  async obtenerFecha(fecha_total) {
    const dia =  new Date(fecha_total).getDate() +1;
    const mes = new Date(fecha_total).getMonth() +1;
    const anio = new Date(fecha_total).getFullYear();
    this.ventas = await this.ventasService.obtenerVentasPorFecha(dia, mes, anio);
  }
}
