import { Component, OnInit} from '@angular/core';
import {Dolar} from "../../modelos/dolar";
import {DolarService} from "../../servicios/dolar.service";
import {MatSnackBar} from "@angular/material/snack-bar";
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-dolar',
  templateUrl: './dolar.component.html',
  styleUrls: ['./dolar.component.css']
})
export class DolarComponent implements OnInit {

  public fechaActual = new Date();
  public dolarModel = new Dolar(this.fechaActual,0);
  public cotizaciones = [];
  public cargando = false;
  public columnas = ['fecha', 'precioventanacion'];
  public dataSource = new MatTableDataSource();
  
  public sortedData = [];

  constructor(private dolarService: DolarService, private snackBar: MatSnackBar) { 
    this.sortedData = this.sortedData.slice();
  }


  ngOnInit(): void {
    this.obtenerCotizaciones();
  }

  async guardar() {
    if (!this.dolarModel.fecha) {
      return alert ('Debe indicar la fecha de cotización');
    }
    if (!this.dolarModel.precioventanacion) {
      return alert ('Debe indicar el valor de cotización');
    }

    this.cargando = true;
    const cotizacionGuardada = await this.dolarService.agregarCotizacion(this.dolarModel);
    this.cargando = false;
    this.dolarModel= new Dolar(this.fechaActual,0);
    this.obtenerCotizaciones();
  }

  async obtenerCotizaciones()  {
    this.dataSource.data = await this.dolarService.obtenerCotizaciones();
    this.cotizaciones = this.dataSource.data;
  }

}

