
import {Component, OnInit} from '@angular/core';
import {VentasService} from "../../servicios/ventas.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-ventas',
  templateUrl: './ventas.component.html',
  styleUrls: ['./ventas.component.css']
})
export class VentasComponent implements OnInit {

  constructor(private ventasService: VentasService, private router:Router) {
  }

  public ventas = [];
  public columnas = ['cliente', 'direccion', 'total', 'fecha', 'detalles'];

  // modificado para mostrar solamente dia actual de ventas
  async ngOnInit() {
    const dia = new Date().getDate();
    const mes = new Date().getMonth()+1;
    const anio: number = new Date().getFullYear();
    this.ventas = await this.ventasService.obtenerVentasPorFecha(dia, mes, anio);
  }

  public verDetalle(id) {
    this.router.navigate(["/detalle-venta", id])
  }

}
