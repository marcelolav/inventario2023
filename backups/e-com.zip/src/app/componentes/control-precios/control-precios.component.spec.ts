import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlPreciosComponent } from './control-precios.component';

describe('ControlPreciosComponent', () => {
  let component: ControlPreciosComponent;
  let fixture: ComponentFixture<ControlPreciosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlPreciosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlPreciosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
