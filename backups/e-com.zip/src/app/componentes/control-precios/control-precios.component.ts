import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-precios',
  templateUrl: './control-precios.component.html',
  styleUrls: ['./control-precios.component.css']
})
export class ControlPreciosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
