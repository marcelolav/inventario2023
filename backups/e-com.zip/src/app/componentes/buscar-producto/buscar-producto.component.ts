import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {ProductosService} from '../../servicios/productos.service'
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { CarritoService } from '../../servicios/carrito.service';

@Component({
  selector: 'app-buscarproductos',
  templateUrl: './buscar-producto.component.html',
  styleUrls: ['./buscar-producto.component.css']
})
export class BuscarProductoComponent implements OnInit {

  public productos = [];
  public columnas = ['codigobarra','nombre', 'descripcion', 'precio', 'preciocompra', 'existencia', 'agregar'];
  public dataSource = new MatTableDataSource();
  constructor(private router: Router, private productosService: ProductosService, private carrito: CarritoService) {
  }

  async eliminar(producto) {
    if (!confirm("¿Realmente lo quieres eliminar<?")) {
      return;
    }
    await this.productosService.eliminarProducto(producto.id);
    await this.obtenerProductos();
  }

  async ngOnInit() {
    await this.obtenerProductos();
  }

  async obtenerProductos() {
    this.dataSource.data = await this.productosService.obtenerProductos();
    this.productos = this.dataSource.data;
  }

  navegarAFormulario() {
    this.router.navigateByUrl("/productos/agregar");
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  
  async agregaProducto(idProducto: number) {
    const id = idProducto;
    const respuesta = await this.carrito.agregarAlCarrito(id);
    this.productos = await this.carrito.obtenerProductos();
  }
}
