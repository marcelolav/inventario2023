/* Creacion de base de datos y tablas correspondientes */
create database ecom
use database ecom

-- Tabla de productos
create table productos(
id bigint unsigned not null auto_increment primary key,
codigobarra varchar(50) not null,
nombre varchar(255) not null,
descripcion varchar(1024) not null,
precio decimal(9,2) not null,
preciocompra decimal(9,2) not null,
existencia int() not null,
preciorefdolar decimal(9,2) not null,
rubroid int 
);

-- Tabla Fotos de productos
create table fotos_productos(
id_producto bigint unsigned not null,
foto varchar(255) not null,
foreign key(id_producto) references productos(id) on delete cascade on update cascade
);

-- Tabla de clientes NO SE UTILIZA
create table clientes(
id bigint unsigned not null auto_increment primary key,
nombre varchar(255) not null,
direccion varchar(255) not null
);
-- Tabla de ventas
create table ventas(
id bigint unsigned not null auto_increment primary key,
id_cliente bigint unsigned not null,
total decimal(9,2) not null,
foreign key(id_cliente) references clientes(id) on delete cascade on update cascade
);
-- Tabla de productos vendidos
create table productos_vendidos(
id_venta bigint unsigned not null,
id_producto bigint unsigned not null,
foreign key(id_venta) references ventas(id) on delete cascade on update cascade,
foreign key(id_producto) references productos(id) on delete cascade on update cascade
);
-- Tabla de proveedores
CREATE TABLE proveedores(
  idproveedor bigint not not null,
  prov_nombre varchar(45) not not null,
  prov_referencia varchar(200) null,
  prov_fucompra datetime null,
  prov_totalgeneral decimal(10,2) null);

CREATE TABLE compras (
  idcompra INT NOT NULL AUTO_INCREMENT,
  idproveedor INT NOT NULL,
  idproducto INT NOT NULL,
  fechacompra DATETIME NOT NULL,
  cantidad INT NOT NULL,
  preciocompra DECIMAL(10,2) NOT NULL,
  preciocompradolar DECIMAL(10,2) NOT NULL );

CREATE TABLE refdolar (
  idrefdolar INT NOT NULL AUTO_INCREMENT,
  fecha DATETIME NOT NULL,
  precioventanacion DECIMAL(10,2) NOT NULL );

CREATE TABLE rubros (
  rubroid INT NOT NULL AUTO_INCREMENT,
  nombrerubro VARCHAR(45) NOT NULL,
  PRIMARY KEY (`rubroid`));
