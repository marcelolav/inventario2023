const conexion = require("./conexion");

module.exports = {

    obtenerTodos() {
        return new Promise((resolve, reject) => {
            conexion.query(`select * FROM refdolar ORDER BY fecha;`,
            (err, resultados) => {
              if (err) reject(err);
              else resolve(resultados);
            });
        })
    },

    obtenerPorFecha(dia, mes, anio) {
        return new Promise((resolve, reject) => {
            conexion.query(`select refdolar.idrefdolar, refdolar.fecha, refdolar.precioventanacion FROM refdolar WHERE day(refdolar.fecha) = ? and month(refdolar.fecha) = ? and year(refdolar.fecha) = ? `,
        [dia, mes, anio],
        (err, resultados) => {
          if (err) reject(err);
          else resolve(resultados);
        });
        })

    },

    insertarRefdolar(fecha, precioventanacion) {
        return new Promise((resolve, reject) => {
            conexion.query(`insert into refdolar (fecha, precioventanacion) values (?, ?)`,
            [fecha, precioventanacion], (err, resultados) => {
                if (err) reject(err);
                else resolve(resultados.insertId);
            });
        });
    }

}