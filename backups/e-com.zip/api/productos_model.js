const conexion = require("./conexion")
const fs = require("fs");
const path = require("path");
module.exports = {
  // agregar producto
  insertar(codigobarra, nombre, descripcion, precio, preciocompra, existencia, refdolar) {
    return new Promise((resolve, reject) => {
      conexion.query(`insert into productos
            (codigobarra, nombre, descripcion, precio, preciocompra, existencia, preciorefdolar)
            values
            (?, ?, ?, ?, ?, ?, ?)`,
        [codigobarra, nombre, descripcion, precio, preciocompra, existencia, refdolar], (err, resultados) => {
          if (err) reject(err);
          else resolve(resultados.insertId);
        });
    });
  },
  agregarFoto(idProducto, nombreFoto) {
    return new Promise((resolve, reject) => {
      conexion.query(`insert into fotos_productos
            (id_producto, foto)
            values
            (?, ?)`,
        [idProducto, nombreFoto], (err, resultados) => {
          if (err) reject(err);
          else resolve(resultados.insertId);
        });
    });
  },
  obtener() {
    return new Promise((resolve, reject) => {
      conexion.query(`select id, codigobarra, nombre, descripcion, precio, preciocompra, existencia, preciorefdolar from productos`,
        (err, resultados) => {
          if (err) reject(err);
          else resolve(resultados);
        });
    });
  },
  obtenerConFotos() {
    return new Promise((resolve, reject) => {
      conexion.query(`select * from productos`,
        async (err, resultados) => {
          if (err) reject(err);
          else {
            /*
              Si existe un dios, que me disculpe por este no-optimizado e ineficiente fragmento de código
             */
            for (let x = 0; x < resultados.length; x++) {
              resultados[x].foto = await this.obtenerPrimeraFoto(resultados[x].id);
            }
            resolve(resultados);
          }
        });
    });
  },
  obtenerPrimeraFoto(idProducto) {
    return new Promise((resolve, reject) => {
      conexion.query(`select foto from fotos_productos WHERE id_producto = ? limit 1`,
        [idProducto],
        (err, resultados) => {
          if (err) reject(err);
          else resolve(resultados[0].foto);
        });
    });
  },
  obtenerFotos(idProducto) {
    return new Promise((resolve, reject) => {
      conexion.query(`select id_producto, foto FROM fotos_productos WHERE id_producto = ?`,
        [idProducto],
        (err, resultados) => {
          if (err) reject(err);
          else resolve(resultados);
        });
    });
  },
  obtenerPorId(id) {
    return new Promise((resolve, reject) => {
      conexion.query(`select id, codigobarra, nombre,descripcion, precio, preciocompra, existencia, preciorefdolar from productos where id = ?`,
        [id],
        (err, resultados) => {
          if (err) reject(err);
          else resolve(resultados[0]);
        });
    });
  },
  obtenerPorCodigoBarra(codigobarra) {
    return new Promise((resolve, reject) => {
      conexion.query(`select id, codigobarra, nombre,descripcion, precio, preciocompra, existencia, preciorefdolar from productos where codigobarra = ?`,
        [id],
        (err, resultados) => {
          if (err) reject(err);
          else resolve(resultados[0]);
        });
    });
  },
  // Actualiza el producto
  actualizar(id, codigobarra, nombre, precio, preciocompra, existencia, preciorefdolar) {
    return new Promise((resolve, reject) => {
      conexion.query(`update productos
            set codigobara =?,
            nombre = ?,
            precio = ?,
            preciocompra = ?,
            existencia,
            preciorefdolar = ?
            where id = ?`,
        [codigobarra, nombre, precio, preciocompra, existencia, preciorefdolar, id],
        (err) => {
          if (err) reject(err);
          else resolve();
        });
    });
  },
  // Eliminar producto
  eliminar(id) {
    return new Promise(async (resolve, reject) => {
      const fotos = await this.obtenerFotos(id);
      for (let m = 0; m < fotos.length; m++) {
        await fs.unlinkSync(path.join(__dirname, "fotos_productos", fotos[m].foto));
      }
      conexion.query(`delete from productos
            where id = ?`,
        [id],
        (err) => {
          if (err) reject(err);
          else resolve();
        });
    });
  },
}
